package Model.Abstract

abstract class Unit() : RealTile(){
    override var occ = true
    override var traverse = false
    override var health = 10
    override var minSal = 0
    override var gasSal = 0
    override var nrgSal = 0
}