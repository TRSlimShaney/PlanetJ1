package Model.Abstract

abstract class Tile() : ITile {
    override fun getPNG() : String {
        return icon
    }
    override var commands = mutableListOf<String>("No commands available")
}