package Model.Abstract


abstract class RealTile(): Tile() {
    override var blank = false
    override var wait = 0
}