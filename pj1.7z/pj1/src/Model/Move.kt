package Model

class Move(val from: Location, val to: Location) {

}