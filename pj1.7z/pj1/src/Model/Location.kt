package Model

class Location(var row: Int, var col: Int) {
    fun setLoc(row: Int, col: Int) {
        this.row = row
        this.col = col
    }
}