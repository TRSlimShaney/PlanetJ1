package Model.Map

import Model.Abstract.BlankTile
import Model.Location


//  because Kotlin is...silly,
//  we need to use mutable lists to get dynamic-sized maps
class Map(val size: Int) {
    val tiles = mutableListOf<Row>()
    init {
        clearMap()
    }

    fun clearMap() {
        for (i in 0 until size) {
            val row = Row()
            for (j in 0 until size) {
                val location = Location(i, j)
                val blank = BlankTile(location)
                row.tiles.add(blank)
            }
            tiles.add(row)
        }
    }
}