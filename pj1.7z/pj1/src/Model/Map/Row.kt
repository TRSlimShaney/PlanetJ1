package Model.Map

import Model.Abstract.ITile

class Row() {
    val tiles = mutableListOf<ITile>()
}