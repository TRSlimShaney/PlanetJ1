using System;
using System.Collections.Generic;

namespace PlanetCS1 {
    class Model {
        int width;
        int height;
        int diff;

        GrassWorld world;
        int size;
        GrassUnits units;
        Map combined;
        Map buffer;
        PlayerUnits playerUnits;
        PlayerBuildings playerBuildings;
        List<ITile> enemyUnits;
        List<Move> enemyMovesQueue;
        List<Move> playerMovesQueue;
        List<ITile> playerBuildQueue;
        List<ITile> playerCreationQueue;
        List<ITile> playerGatherQueue;
        GameData playerData;
        Location viewscreen;
        int gameWon;

        public Model(int width, int height, int diff) {
            this.width = width;
            this.height = height;
            this.diff = diff;
            setupUnits();
            setupBuildings();
            updateView(5, 5);
        }
    }
}