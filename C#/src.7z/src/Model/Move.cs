using System;

namespace PlanetCS1 {
    class Move {
        Location from;
        Location to;
        Move(Location from, Location to) {
            this.from = from;
            this.to = to;
        }
    }
}