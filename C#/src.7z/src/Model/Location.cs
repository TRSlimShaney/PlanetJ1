using System;

namespace PlanetCS1 {
    public class Location {
        int row;
        int col;
        public Location(int row, int col) {
            this.row = row;
            this.col = col;
        }

        void setLoc (int row, int col) {
            this.row = row;
            this.col = col;
        }
    }
}